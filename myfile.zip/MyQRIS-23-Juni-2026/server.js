require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const MemoryStore = require('memorystore')(session);
const rateLimit = require('express-rate-limit');
const axios = require('axios');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const { Telegraf } = require('telegraf');
const archiver = require('archiver');

const app = express();
app.set('trust proxy', 1);
const PORT = process.env.PORT || 3000;

// ~~~~~~~~ CUSTOM ID PREFIX
const startId = {
  apikey: 'SKY',
  invoice: 'INV',
  withdraw: 'WD',
  transaction: 'TRX'
};

// ~~~~~~~~ MIDDLEWARE DASAR
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: crypto.randomBytes(32).toString('hex'),
  resave: false,
  store: new MemoryStore({ checkPeriod: 86400000 }),
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ~~~~~~~~ SETUP LIMITER
const Limiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 15,
  handler: (req, res) => {
    req.session.errorMsg = 'Terlalu banyak percobaan login. Silakan coba lagi setelah 5 menit.';
    res.redirect('/login');
  }
});

// ~~~~~~~~ MONGODB
mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log('✅ MongoDB terhubung');
    await seed();
    botManager = new BotManager({ Setting, User, Withdrawal, Transaction, Stats, Invoice });
    await botManager.init();
    await botManager.manageBot();
  })
  .catch(err => console.error('❌ MongoDB gagal:', err));

// ~~~~~~~~ CUSTOM ID GENERATOR
function generateCustomId(prefix) {
  const len = 10 - prefix.length;
  const randomHex = crypto.randomBytes(Math.ceil(len / 2)).toString('hex').substring(0, len);
  return prefix + randomHex;
}
function generateApiKey() {
  return startId.apikey + '_' + crypto.randomUUID().replace(/-/g, '').substring(0, 16);
}

// ~~~~~~~~ MODELS
const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    validate: {
      validator: function(v) { return /^[a-zA-Z0-9]+$/.test(v); },
      message: 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)'
    },
    maxlength: [15, 'Username maksimal 15 karakter']
  },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  balance: { type: Number, default: 0 },
  role: { type: String, default: 'user', enum: ['user', 'admin'] },
  suspended: { type: Boolean, default: false },
  resetPasswordToken: String,
  resetPasswordExpires: Date,
  createdAt: { type: Date, default: Date.now }
});
const User = mongoose.model('User', userSchema);

const invoiceSchema = new mongoose.Schema({
  _id: { type: String, default: () => generateCustomId(startId.invoice) },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  amount: Number,
  fee: Number,
  total: Number,
  trxid: String,
  qris_image: String,
  mutationId: { type: String, default: null },
  expiredAt: Date,
  status: { type: String, default: 'pending', enum: ['pending', 'paid', 'expired'] },
  createdAt: { type: Date, default: Date.now }
});
const Invoice = mongoose.model('Invoice', invoiceSchema);

const transactionSchema = new mongoose.Schema({
  _id: { type: String, default: () => generateCustomId(startId.transaction) },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  type: { type: String, enum: ['deposit', 'withdraw'] },
  amount: Number,
  fee: Number,
  qris_image: String,
  status: String,
  reference: String,
  expiredAt: Date,
  createdAt: { type: Date, default: Date.now },
  adminNote: String,
  completedAt: Date,
  method: String,
  accountNumber: String,
  instant: { type: Boolean, default: false }
});
const Transaction = mongoose.model('Transaction', transactionSchema);

const withdrawSchema = new mongoose.Schema({
  _id: { type: String, default: () => generateCustomId(startId.withdraw) },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  amount: Number,
  fee: Number,
  method: String,
  accountNumber: String,
  status: { type: String, default: 'pending', enum: ['pending', 'success', 'rejected'] },
  adminNote: String,
  completedAt: Date,
  createdAt: { type: Date, default: Date.now },
  instant: { type: Boolean, default: false },
  destination: { type: String, default: '' },
  h2hRefId: { type: String, default: '' },
  h2hResponse: { type: String, default: '' },
  methodCode: { type: String, default: '' }
});
const Withdrawal = mongoose.model('Withdrawal', withdrawSchema);

const apiKeySchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  key: { type: String, unique: true },
  createdAt: { type: Date, default: Date.now }
});
const ApiKey = mongoose.model('ApiKey', apiKeySchema);

const settingSchema = new mongoose.Schema({
  name: { type: String, default: 'Sky Gateway' },
  title: { type: String, default: 'Layanan Payment Gateway' },
  description: { type: String, default: 'Terima pembayaran melalui QRIS Payment untuk Aplikasi atau Platform Bisnis kamu dengan mudah, cepat, dan aman.' },
  contactDeveloper: { type: String, default: 'https://t.me/Xskycode' },
  channelInformation: { type: String, default: 'https://whatsapp.com/channel/0029VbCTqG7Fsn0fJzxg1B1H' },
  minDeposit: { type: Number, default: 1000 },
  minWithdraw: { type: Number, default: 5000 },
  maxFee: { type: Number, default: 500 },
  checkInterval: { type: Number, default: 30 },
  qrisExpiredMinutes: { type: Number, default: 30 },
  smtpUser: { type: String, default: '' },
  smtpPass: { type: String, default: '' },
  logoUrl: { type: String, default: 'https://img2.pixhost.to/images/8187/731158188_skyzo.png' },
  gopayDomain: { type: String, default: 'gomerch.vercel.app' },
  gopayToken: { type: String, default: '' },
  gopayStaticQr: { type: String, default: '' },
  gopayRefreshToken: { type: String, default: '' },
  // ===== TAMBAHAN: Provider Payment Gateway =====
  paymentGateway: { type: String, default: 'gopaymerchant', enum: ['gopaymerchant', 'orderkuota'] },
  orderkuotaDomain: { type: String, default: '' },
  orderkuotaApiKey: { type: String, default: '' },
  orderkuotaUsername: { type: String, default: '' },
  orderkuotaToken: { type: String, default: '' },
  // ============================================
  telegramBotToken: { type: String, default: '' },
  telegramOwnerId: { type: String, default: '' },
  telegramBotEnabled: { type: Boolean, default: false },
  withdrawMethods: {
    type: [
      {
        name: { type: String, required: true },
        fee: { type: Number, required: true, default: 1000 },
        min: { type: Number, default: 0 }
      }
    ],
    default: [
      { name: 'Dana', fee: 1000, min: 10000 },
      { name: 'GoPay', fee: 2000, min: 10000 }
    ]
  },
  h2hIdMerchant: { type: String, default: '' },
  h2hPin: { type: String, default: '' },
  h2hPassword: { type: String, default: '' },
  instantWithdrawMethods: {
    type: [
      {
        name: { type: String, required: true },
        code: { type: String, required: true },
        fee: { type: Number, required: true, default: 1000 },
        minAmount: { type: Number, required: true, default: 10000 },
        active: { type: Boolean, default: true }
      }
    ],
    default: [
      { name: 'Dana', code: 'BBSD', fee: 1000, minAmount: 10000, active: true },
      { name: 'GoPay', code: 'BBSGOP', fee: 2000, minAmount: 10000, active: true }
    ]
  }
});
const Setting = mongoose.model('Setting', settingSchema);

const statsSchema = new mongoose.Schema({
  totalDepositAmount: { type: Number, default: 0 },
  totalDepositFee: { type: Number, default: 0 },
  totalWithdrawAmount: { type: Number, default: 0 },
  totalWithdrawFee: { type: Number, default: 0 },
  totalUsers: { type: Number, default: 0 },
  totalTransactions: { type: Number, default: 0 },
  totalUserBalance: { type: Number, default: 0 }
});
const Stats = mongoose.model('Stats', statsSchema);

// ~~~~~~~~ UPLOAD CONFIGURATIONS
const uploadsDir = path.join(__dirname, 'public');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const logoStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, 'logo-' + Date.now() + '-' + crypto.randomBytes(4).toString('hex') + ext);
  }
});
const logoUpload = multer({
  storage: logoStorage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) return cb(new Error('Hanya file gambar yang diizinkan'), false);
    cb(null, true);
  }
});

// ~~~~~~~~ ANTI-DUPLICATE HELPER
async function createWithRetry(Model, data, maxRetries = 5) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await Model.create(data);
    } catch (err) {
      if (err.code === 11000 && attempt < maxRetries - 1) {
        if (Model === Invoice) data._id = generateCustomId(startId.invoice);
        else if (Model === Transaction) data._id = generateCustomId(startId.transaction);
        else if (Model === Withdrawal) data._id = generateCustomId(startId.withdraw);
        else if (Model === ApiKey) data.key = generateApiKey();
        continue;
      }
      throw err;
    }
  }
  throw new Error('Gagal membuat dokumen setelah beberapa kali percobaan (duplicate ID)');
}

// ~~~~~~~~ HELPERS
async function getSettings() {
  let s = await Setting.findOne();
  if (!s) s = await Setting.create({});
  return s;
}

async function computeStats() {
  const [
    depositAgg,
    withdrawAgg,
    totalUsers,
    totalTrx,
    balanceAgg
  ] = await Promise.all([
    Transaction.aggregate([
      { $match: { type: 'deposit', status: 'paid' } },
      { $group: { _id: null, totalAmount: { $sum: '$amount' }, totalFee: { $sum: '$fee' } } }
    ]),
    Transaction.aggregate([
      { $match: { type: 'withdraw', status: 'success' } },
      { $group: { _id: null, totalAmount: { $sum: '$amount' }, totalFee: { $sum: '$fee' } } }
    ]),
    User.countDocuments({ role: 'user' }),
    Transaction.countDocuments(),
    User.aggregate([
      { $match: { role: 'user' } },
      { $group: { _id: null, totalBalance: { $sum: '$balance' } } }
    ])
  ]);

  const dAmount = depositAgg[0]?.totalAmount || 0;
  const dFee = depositAgg[0]?.totalFee || 0;
  const wAmount = withdrawAgg[0]?.totalAmount || 0;
  const wFee = withdrawAgg[0]?.totalFee || 0;
  const totalUserBalance = balanceAgg[0]?.totalBalance || 0;

  await Stats.findOneAndUpdate({}, {
    totalDepositAmount: dAmount,
    totalDepositFee: dFee,
    totalWithdrawAmount: wAmount,
    totalWithdrawFee: wFee,
    totalUsers,
    totalTransactions: totalTrx,
    totalUserBalance
  }, { upsert: true });

  return {
    totalDepositAmount: dAmount,
    totalDepositFee: dFee,
    totalWithdrawAmount: wAmount,
    totalWithdrawFee: wFee,
    totalUsers,
    totalTransactions: totalTrx,
    totalUserBalance
  };
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}
function verifyPassword(password, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex') === hash;
}

// ~~~~~~~~ GOPAY TOKEN REFRESH & RETRY
let refreshingPromise = null;

async function refreshGopayToken() {
  const settings = await getSettings();
  if (!settings.gopayRefreshToken) {
    const err = new Error('Refresh token tidak tersedia. Harap isi di pengaturan admin.');
    if (botManager) botManager.notifyError('refreshGopayToken', err.message);
    throw err;
  }
  const gopayBase = settings.gopayDomain || 'gomerch.vercel.app';
  const refreshUrl = `https://${gopayBase}/auth/refresh/token?refresh_token=${encodeURIComponent(settings.gopayRefreshToken)}`;
  try {
    const resp = await axios.get(refreshUrl);
    const res = resp.data;
    if (!res.success) {
      const err = new Error(res.error || 'Gagal refresh token');
      if (botManager) botManager.notifyError('/auth/refresh/token', err.message);
      throw err;
    }
    const newToken = res.data.access_token;
    const newRefreshToken = res.data.refresh_token;
    const updateFields = { gopayToken: newToken };
    if (newRefreshToken) updateFields.gopayRefreshToken = newRefreshToken;
    await Setting.updateOne({}, updateFields);
    console.log('✅ Gopay token berhasil diperbarui');
    return newToken;
  } catch (err) {
    console.error('❌ Gagal refresh Gopay token:', err.response?.data || err.message);
    if (botManager) botManager.notifyError('/auth/refresh/token', err.response?.data?.error || err.message);
    throw new Error('Gagal memperbarui token Gopay. Refresh token mungkin sudah kadaluarsa.');
  }
}

async function callGopayApiWithRetry(url, options = {}, maxRetries = 1) {
  let lastError;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await axios({ url, ...options });
      return response.data;
    } catch (err) {
      const isTokenError =
        (err.response && err.response.status === 401) ||
        (err.response?.data?.error &&
          (typeof err.response.data.error === 'string'
            ? /Expired token/i.test(err.response.data.error)
            : /Expired token/i.test(err.response.data.error?.message || '')));
      if (isTokenError && attempt < maxRetries) {
        console.log('🔄 Token expired, mencoba refresh...');
        if (!refreshingPromise) {
          refreshingPromise = refreshGopayToken().finally(() => { refreshingPromise = null; });
        }
        try {
          await refreshingPromise;
        } catch (refreshError) { throw refreshError; }
        const settings = await getSettings();
        if (url.includes('token=')) url = url.replace(/token=[^&]*/, `token=${encodeURIComponent(settings.gopayToken)}`);
        continue;
      }
      lastError = err;
      break;
    }
  }
  if (lastError && botManager) botManager.notifyError(url, lastError.response?.data?.error || lastError.message);
  throw lastError;
}

// ~~~~~~~~ BOT MANAGER
class BotManager {
  constructor(models) {
    this.models = models;
    this.bot = null;
    this.running = false;
    this.settings = null;
  }

  async init() {
    this.settings = await this.models.Setting.findOne();
  }

  async updateSettings(newSettings) {
    this.settings = newSettings;
    await this.manageBot();
  }

  async manageBot() {
    if (!this.settings) return;
    const { telegramBotEnabled, telegramBotToken, telegramOwnerId } = this.settings;
    if (telegramBotEnabled && telegramBotToken && telegramOwnerId) {
      if (!this.running) {
        await this.startBot(telegramBotToken, telegramOwnerId);
      } else if (this.bot && this.bot.token !== telegramBotToken) {
        await this.stopBot();
        await this.startBot(telegramBotToken, telegramOwnerId);
      }
    } else {
      if (this.running) await this.stopBot();
    }
  }
  
  async restartBot() {
  if (!this.settings) throw new Error('Settings belum dimuat.');
  const { telegramBotToken, telegramOwnerId } = this.settings;
  if (!telegramBotToken || !telegramOwnerId) {
    throw new Error('Token Bot atau Owner ID belum diisi di Pengaturan.');
  }
  await this.stopBot();
  await this.startBot(telegramBotToken, telegramOwnerId);
}

  async startBot(token, ownerId) {
    this.bot = new Telegraf(token);
    this.ownerId = ownerId;

    this.bot.command('stats', async (ctx) => {
      const stats = await computeStats();
      const msg = `📊 *Statistik Keuangan ${this.settings.name}*\n` +
        `_- Total Deposit:_ Rp ${stats.totalDepositAmount.toLocaleString('id-ID')}\n` +
        `_- Total Fee Deposit:_ Rp ${stats.totalDepositFee.toLocaleString('id-ID')}\n` +
        `_- Total Withdraw:_ Rp ${stats.totalWithdrawAmount.toLocaleString('id-ID')}\n` +
        `_- Total Fee Withdraw:_ Rp ${stats.totalWithdrawFee.toLocaleString('id-ID')}\n` +
        `_- Total Pengguna:_ ${stats.totalUsers}\n` +
        `_- Total Transaksi:_ ${stats.totalTransactions}\n` +
        `_- Total Saldo User:_ Rp ${stats.totalUserBalance.toLocaleString('id-ID')}`;
      ctx.replyWithMarkdown(msg);
    });

    this.bot.command('menu', async (ctx) => {
      const keyboard = [
        [{ text: '📊 Stats', callback_data: 'stats' }, { text: '📤 Backup Script', callback_data: 'backup' }],
        [{ text: '🌐 Buka Web MyQRIS', url: 'https://myqris.my.id' }]
      ];
      await ctx.reply(`_Hallo 👋_,\n_Saya adalah bot notifikasi_ *MyQRIS*`, {
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: keyboard }
      });
    });

    this.bot.command('backup', async (ctx) => {
      if (ctx.from.id.toString() !== this.ownerId.toString()) return ctx.reply('⚠️ Hanya owner yang dapat menggunakan fitur ini.');
      this.createBackup(ctx);
    });

    this.bot.action('backup', async (ctx) => {
      if (ctx.from.id.toString() !== this.ownerId.toString()) { await ctx.answerCbQuery('⚠️ Hanya owner yang dapat menggunakan fitur ini.'); return; }
      await ctx.answerCbQuery();
      this.createBackup(ctx);
    });

    this.bot.action('stats', async (ctx) => {
      await ctx.answerCbQuery();
      const stats = await computeStats();
      const msg = `📊 *Statistik Keuangan ${this.settings.name}*\n` +
        `_- Total Deposit:_ Rp ${stats.totalDepositAmount.toLocaleString('id-ID')}\n` +
        `_- Total Fee Deposit:_ Rp ${stats.totalDepositFee.toLocaleString('id-ID')}\n` +
        `_- Total Withdraw:_ Rp ${stats.totalWithdrawAmount.toLocaleString('id-ID')}\n` +
        `_- Total Fee Withdraw:_ Rp ${stats.totalWithdrawFee.toLocaleString('id-ID')}\n` +
        `_- Total Pengguna:_ ${stats.totalUsers}\n` +
        `_- Total Transaksi:_ ${stats.totalTransactions}\n` +
        `_- Total Saldo User:_ Rp ${stats.totalUserBalance.toLocaleString('id-ID')}`;
      await ctx.reply(msg, { parse_mode: 'Markdown' });
    });

    this.bot.on('callback_query', async (ctx) => {
      const ownerId = this.ownerId.toString();
      if (ctx.from.id.toString() !== ownerId) return;
      const data = ctx.callbackQuery.data;
      if (data.startsWith('approve_')) {
        const wdId = data.split('_')[1];
        await this.approveWithdrawal(ctx, wdId);
      } else if (data.startsWith('reject_')) {
        const wdId = data.split('_')[1];
        await this.showRejectReasons(ctx, wdId);
      } else if (data.startsWith('rejectReason_')) {
        const [, wdId, reasonIndex] = data.split('_');
        const reasons = ['Data Ewallet Tidak Valid', 'Nama Akun Tidak Valid', 'Metode Penarikan Tidak Valid'];
        const reason = reasons[parseInt(reasonIndex)] || 'Alasan tidak diketahui';
        await this.rejectWithdrawal(ctx, wdId, reason);
      } else if (data.startsWith('cancelReject_')) {
        const wdId = data.split('_')[1];
        const keyboard = { inline_keyboard: [[{ text: '✅ Approve', callback_data: `approve_${wdId}` }, { text: '❌ Reject', callback_data: `reject_${wdId}` }]] };
        try { await ctx.editMessageReplyMarkup(keyboard); } catch (e) { console.error('Gagal mengembalikan tombol:', e); this.notifyError('/callback_query (cancelReject)', e.message); }
      }
      ctx.answerCbQuery();
    });

    this.bot.catch((err) => {
      console.error('Bot error:', err);
      this.notifyError('Bot Generic Error', err.message);
    });

    try {
      this.bot.launch();
      this.running = true;
      console.log('✅ Bot Telegram berjalan');
      try { await this.bot.telegram.sendMessage(this.ownerId, '✅ *Bot Berhasil Tersambung*\nSiap mengirim notifikasi.', { parse_mode: 'Markdown' }); } catch (e) { console.error('Gagal kirim notifikasi tersambung:', e.message); }
    } catch (e) {
      console.error('❌ Gagal menjalankan bot:', e.message);
      this.running = false;
    }
  }

  async stopBot() {
    if (this.bot) { this.bot.stop(); this.bot = null; this.running = false; console.log('⏹️ Bot Telegram dihentikan'); }
  }

  isRunning() { return this.running; }

  async notifyDeposit(invoice, user) {
    if (!this.running || !this.bot || !this.ownerId) return;
    const msg = `💰 *Deposit Berhasil*\n` +
      `_- Invoice ID:_ \`${invoice._id}\`\n` +
      `_- User:_ ${user.username}\n` +
      `_- Jumlah:_ Rp ${invoice.amount.toLocaleString('id-ID')}\n` +
      `_- Biaya:_ Rp ${invoice.fee.toLocaleString('id-ID')}\n` +
      `_- Total:_ Rp ${invoice.total.toLocaleString('id-ID')}\n` +
      `_- Waktu:_ ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }).replace(/\./g, ':')}`;
    try { await this.bot.telegram.sendMessage(this.ownerId, msg, { parse_mode: 'Markdown' }); } catch (e) { console.error('Notif deposit gagal:', e); }
  }

  async notifyWithdrawRequest(withdrawal, user) {
    if (!this.running || !this.bot || !this.ownerId) return;
    const msg = `🏧 *Permintaan Withdraw Baru*\n` +
      `_- ID:_ \`${withdrawal._id}\`\n` +
      `_- User:_ ${user.username}\n` +
      `_- Metode:_ ${withdrawal.method}\n` +
      `_- No.Rekening:_ \`${withdrawal.accountNumber}\`\n` +
      `_- Jumlah:_ Rp ${withdrawal.amount.toLocaleString('id-ID')}\n` +
      `_- Biaya:_ Rp ${withdrawal.fee.toLocaleString('id-ID')}\n` +
      `_- Waktu:_ ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }).replace(/\./g, ':')}`;
    const keyboard = { inline_keyboard: [[{ text: '✅ Approve', callback_data: `approve_${withdrawal._id}` }, { text: '❌ Reject', callback_data: `reject_${withdrawal._id}` }]] };
    try { await this.bot.telegram.sendMessage(this.ownerId, msg, { reply_markup: keyboard, parse_mode: 'Markdown' }); } catch (e) { console.error('Notif withdraw gagal:', e); }
  }

  async notifyInstantWithdraw(withdrawal, user, failed = false, reason = '') {
    if (!this.running || !this.bot || !this.ownerId) return;
    const header = failed ? '❌ *Withdraw Instan Gagal*' : '⚡ *Withdraw Instan Berhasil*';
    const time = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }).replace(/\./g, ':');
    let msg = `${header}\n` +
      `_- ID:_ \`${withdrawal._id}\`\n` +
      `_- User:_ ${user.username}\n` +
      `_- Metode:_ ${withdrawal.method}\n` +
      `_- Tujuan:_ \`${withdrawal.destination}\`\n` +
      `_- Jumlah:_ Rp ${withdrawal.amount.toLocaleString('id-ID')}\n` +
      `_- Biaya:_ Rp ${withdrawal.fee.toLocaleString('id-ID')}\n` +
      `_- Waktu:_ ${time}`;
    if (failed && reason) msg += `\n_- Alasan:_ ${reason}`;
    try { await this.bot.telegram.sendMessage(this.ownerId, msg, { parse_mode: 'Markdown' }); } catch (e) { console.error('Notif withdraw instan gagal:', e); }
  }

  async notifyError(endpoint, errorMessage) {
    if (!this.running || !this.bot || !this.ownerId) return;
    const time = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }).replace(/\./g, ':');
    const msg = `⚠️ *Error Terdeteksi*\n_- Endpoint:_ \`${endpoint}\`\n_- Waktu:_ ${time}\n_- Pesan:_ ${errorMessage}`;
    try { await this.bot.telegram.sendMessage(this.ownerId, msg, { parse_mode: 'Markdown' }); } catch (e) { console.error('Gagal kirim notifikasi error:', e); }
  }

  async createBackup(ctx) {
    try {
      const Id = await ctx.reply("🔄 Backup Processing...");
      await ctx.telegram.deleteMessage(ctx.chat.id, Id.message_id);
      const bulanIndo = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
      const tgl = new Date();
      const tanggal = tgl.getDate().toString().padStart(2,"0");
      const bulan = bulanIndo[tgl.getMonth()];
      const name = `MyQRIS-${tanggal}-${bulan}-${tgl.getFullYear()}`;
      const exclude = ["node_modules","package-lock.json","yarn.lock",".npm",".cache",".git"];
      const filesToZip = fs.readdirSync(".").filter(f => !exclude.includes(f) && !f.startsWith('.') && f !== "");
      if (!filesToZip.length) return ctx.reply("❌ Tidak ada file yang dapat di backup!");
      const output = fs.createWriteStream(`./${name}.zip`);
      const archive = archiver("zip", { zlib: { level: 9 } });
      output.on('close', async () => {
        console.log(`Backup created: ${archive.pointer()} total bytes`);
        try {
          await ctx.telegram.sendDocument(this.ownerId, { source: `./${name}.zip` }, { caption: `✅ <b>Backup Script selesai!</b>`, parse_mode: "HTML" });
          fs.unlinkSync(`./${name}.zip`);
          if (ctx.chat.id.toString() !== this.ownerId.toString()) await ctx.reply("✅ <b>Backup script selesai!</b>\n📁 File telah dikirim ke chat pribadi owner.", { parse_mode: "HTML" });
        } catch (err) { console.error("Gagal kirim file backup:", err); this.notifyError('/backup (sendDocument)', err.message); await ctx.reply("❌ Error! Gagal mengirim file backup."); }
      });
      archive.on('error', async (err) => { console.error("Archive Error:", err); this.notifyError('/backup (archive)', err.message); await ctx.reply("❌ Error! Gagal membuat file backup."); });
      archive.pipe(output);
      for (let file of filesToZip) { const stat = fs.statSync(file); if (stat.isDirectory()) archive.directory(file, file); else archive.file(file, { name: file }); }
      await archive.finalize();
    } catch (err) { console.error("Backup Error:", err); this.notifyError('/backup (global)', err.message); await ctx.reply("❌ Error! Terjadi kesalahan saat proses backup."); }
  }

  async approveWithdrawal(ctx, wdId) {
    try {
      const wd = await this.models.Withdrawal.findById(wdId);
      if (!wd || wd.status !== 'pending') return ctx.editMessageText('⚠️ Withdrawal tidak ditemukan atau sudah diproses.');
      wd.status = 'success'; wd.completedAt = new Date(); await wd.save();
      await this.models.Transaction.updateOne(
        { userId: wd.userId, type: 'withdraw', status: 'pending', reference: { $regex: /^W/ } },
        { status: 'success', completedAt: new Date() }
      );
      const newText = ctx.callbackQuery.message.text + '\n\n✅ *Approved*';
      await ctx.editMessageText(newText, { parse_mode: 'Markdown' });
    } catch (e) { console.error(e); this.notifyError('/approveWithdrawal', e.message); ctx.editMessageText('❌ Gagal approve.'); }
  }

  async showRejectReasons(ctx, wdId) {
    const keyboard = { inline_keyboard: [
      [{ text: '1. Data Ewallet Tidak Valid', callback_data: `rejectReason_${wdId}_0` }],
      [{ text: '2. Nama Akun Tidak Valid', callback_data: `rejectReason_${wdId}_1` }],
      [{ text: '3. Metode Penarikan Tidak Valid', callback_data: `rejectReason_${wdId}_2` }],
      [{ text: '🔙 Batalkan', callback_data: `cancelReject_${wdId}` }]
    ]};
    await ctx.editMessageReplyMarkup(keyboard);
  }

  async rejectWithdrawal(ctx, wdId, reason) {
    try {
      const wd = await this.models.Withdrawal.findById(wdId);
      if (!wd || wd.status !== 'pending') return ctx.editMessageText('⚠️ Withdrawal tidak ditemukan atau sudah diproses.');
      wd.status = 'rejected'; wd.adminNote = reason; wd.completedAt = new Date(); await wd.save();
      await this.models.User.findByIdAndUpdate(wd.userId, { $inc: { balance: wd.amount + wd.fee } });
      await this.models.Transaction.updateOne(
        { userId: wd.userId, type: 'withdraw', status: 'pending', reference: { $regex: /^W/ } },
        { status: 'rejected', adminNote: reason, completedAt: new Date() }
      );
      const newText = ctx.callbackQuery.message.text + `\n\n❌ *Ditolak*\nAlasan: ${reason}`;
      await ctx.editMessageText(newText, { parse_mode: 'Markdown' });
    } catch (e) { console.error(e); this.notifyError('/rejectWithdrawal', e.message); ctx.editMessageText('❌ Gagal reject.'); }
  }
}

let botManager = null;

// ~~~~~~~~ GLOBAL MIDDLEWARE
app.use(async (req, res, next) => {
  res.locals.user = null;
  if (req.session.userId) {
    try {
      const user = await User.findById(req.session.userId);
      if (user) res.locals.user = user.toObject();
    } catch {}
  }
  res.locals.settings = await getSettings();
  res.locals.error = req.session.errorMsg || null;
  res.locals.success = req.session.successMsg || null;
  delete req.session.errorMsg;
  delete req.session.successMsg;
  next();
});

function isAuth(req, res, next) {
  if (req.session.userId) return next();
  res.redirect('/login');
}
function isAdmin(req, res, next) {
  if (req.session.userRole === 'admin') return next();
  res.redirect('/login');
}

// ~~~~~~~~ SEED
async function seed() {
  const ex = await User.findOne({ role: "admin" });
  if (!ex) {
    await User.create({ username: 'admin', email: 'admin@gmail.com', password: hashPassword('admin123'), role: 'admin' });
    console.log(`🔑 Admin Account Default\nUsername: admin\nPassword: admin123`);
  }
  const settings = await getSettings();
  if (!settings.withdrawMethods || settings.withdrawMethods.length === 0) {
    settings.withdrawMethods = [{ name: 'Dana', fee: 1000, min: 10000 }, { name: 'GoPay', fee: 2000, min: 10000 }];
    await settings.save();
  }
}

// ~~~~~~~~ ROUTES DASHBOARD / AUTH
app.get('/', async (req, res) => {
  const stats = await computeStats();
  res.render('home', { stats });
});

app.get('/login', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('login');
});
app.get('/register', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('register');
});

app.post('/login', Limiter, async (req, res) => {
  const { login, password } = req.body;
  if (!login || !password) { req.session.errorMsg = 'Harap isi semua field'; return res.redirect('/login'); }
  const isEmail = login.includes('@');
  let user;
  if (isEmail) {
    user = await User.findOne({ email: login.toLowerCase() });
    if (user && user.role === 'admin') { req.session.errorMsg = 'Admin hanya dapat login menggunakan username'; return res.redirect('/login'); }
  } else {
    user = await User.findOne({ username: login.toLowerCase() });
  }
  if (!user || !verifyPassword(password, user.password)) { req.session.errorMsg = 'Username/email atau kata sandi salah'; return res.redirect('/login'); }
  if (user.suspended) { req.session.errorMsg = 'Akun Anda dinonaktifkan'; return res.redirect('/login'); }
  req.session.userId = user._id;
  req.session.userRole = user.role;
  if (user.role === 'admin') return res.redirect('/admin/dashboard');
  res.redirect('/dashboard');
});

app.post('/register', Limiter, async (req, res) => {
  const { username, email, password } = req.body;
  if (!username || username.trim().length === 0) { req.session.errorMsg = 'Username tidak boleh kosong'; return res.redirect('/register'); }
  if (!/^[a-zA-Z0-9]+$/.test(username)) { req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)'; return res.redirect('/register'); }
  if (username.length > 15) { req.session.errorMsg = 'Username maksimal 15 karakter'; return res.redirect('/register'); }
  try {
    const user = await User.create({ username, email, password: hashPassword(password) });
    await createWithRetry(ApiKey, { userId: user._id, key: generateApiKey() });
    req.session.userId = user._id;
    req.session.userRole = 'user';
    res.redirect('/dashboard');
  } catch (err) {
    if (err.code === 11000) req.session.errorMsg = 'Username atau email sudah terdaftar';
    else if (err.name === 'ValidationError') req.session.errorMsg = Object.values(err.errors).map(e => e.message).join(', ');
    else req.session.errorMsg = 'Gagal mendaftar, periksa kembali data Anda';
    res.redirect('/register');
  }
});

app.post('/check-availability', async (req, res) => {
  const { type, value } = req.body;
  if (!type || !value || !['username', 'email'].includes(type)) return res.json({ available: false, message: 'Parameter tidak valid' });
  if (type === 'username') {
    if (!/^[a-zA-Z0-9]{1,15}$/.test(value)) return res.json({ available: false, message: 'Format username tidak valid (huruf/angka, maks 15 karakter)' });
    const exists = await User.findOne({ username: value.toLowerCase() });
    return res.json({ available: !exists, message: exists ? 'Username sudah digunakan' : 'Username tersedia' });
  }
  if (type === 'email') {
    if (!/^\S+@\S+\.\S+$/.test(value)) return res.json({ available: false, message: 'Format email tidak valid' });
    const exists = await User.findOne({ email: value.toLowerCase() });
    return res.json({ available: !exists, message: exists ? 'Email sudah terdaftar' : 'Email tersedia' });
  }
});

app.get('/forgot-password', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('forgot_password');
});
app.post('/forgot-password', Limiter, async (req, res) => {
  const { login } = req.body;
  if (!login) { req.session.errorMsg = 'Harap masukkan email atau username Anda.'; return res.redirect('/forgot-password'); }
  try {
    const settings = await getSettings();
    if (!settings.smtpUser || !settings.smtpPass) { req.session.errorMsg = 'Fitur lupa password belum tersedia.'; return res.redirect('/forgot-password'); }
    const isEmail = login.includes('@');
    let user;
    if (isEmail) user = await User.findOne({ email: login.toLowerCase() });
    else user = await User.findOne({ username: login.toLowerCase() });
    if (!user) { req.session.errorMsg = 'Akun tidak ditemukan.'; return res.redirect('/forgot-password'); }
    if (!user.email) { req.session.errorMsg = 'Akun ini tidak memiliki alamat email yang valid.'; return res.redirect('/forgot-password'); }
    const token = crypto.randomBytes(32).toString('hex');
    user.resetPasswordToken = token;
    user.resetPasswordExpires = Date.now() + 30 * 60 * 1000;
    await user.save();

    const resetLink = `http://${req.headers.host}/reset-password/${token}`;
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com', port: 587, secure: false,
      auth: { user: settings.smtpUser, pass: settings.smtpPass },
      tls: { rejectUnauthorized: false },
      connectionTimeout: 10000, greetingTimeout: 10000, socketTimeout: 10000
    });
    await transporter.sendMail({
      to: user.email,
      from: `"${settings.name}" <${settings.smtpUser}>`,
      subject: `Permintaan Reset Password`,
      html: `<div style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;background-color:#f9f9f9;padding:40px 20px;margin:0;"><div style="max-width:500px;margin:0 auto;background-color:#ffffff;border:1px solid #dddddd;border-radius:2px;overflow:hidden;"><div style="padding:28px 24px 0;text-align:center;"><h2 style="color:#1f2937;font-size:18px;font-weight:600;margin:0 0 4px;">${settings.name}</h2><p style="color:#1f2937;font-size:14px;margin:0 0 4px;">${settings.title}</p></div><div style="padding:24px;"><p style="color:#4b5563;font-size:14px;line-height:1.5;margin:0 0 20px;">Halo <strong style="color:#1f2937;">${user.username}</strong>, Kami menerima permintaan untuk mengatur ulang kata sandi akun Anda di <strong>${settings.name}</strong>. Jika ini memang Anda, silakan klik tombol di bawah ini:</p><div style="text-align:center;margin-bottom:24px;"><a href="${resetLink}" style="display:inline-block;background-color:#3b82f6;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:2px;font-weight:600;font-size:14px;line-height:1.5;">Ganti Password Saya</a></div><p style="color:#dc2626;font-size:13px;font-weight:600;text-align:center;margin-bottom:24px;background-color:#fef2f2;border:1px solid #fecaca;padding:10px 14px;border-radius:2px;">Tautan ini hanya berlaku selama 30 menit.</p><div style="border-top:1px solid #dddddd;padding-top:20px;margin-top:8px;"><p style="color:#9ca3af;font-size:14px;line-height:1.5;margin:0;">Jika tombol di atas tidak berfungsi, salin dan tempel URL berikut ke browser Anda:<br><a href="${resetLink}" style="color:#3b82f6;word-break:break-all;text-decoration:none;">${resetLink}</a></p></div></div></div><div style="text-align:center;max-width:480px;margin:20px auto 0;"><p style="color:#9ca3af;font-size:14px;margin:0;">&copy; ${new Date().getFullYear()} ${settings.name}. All rights reserved.</p></div></div>`
    });
    req.session.successMsg = `Link reset password telah dikirim ke email.`;
    res.redirect('/forgot-password');
  } catch (error) {
    console.error('Error Forgot Password:', error);
    if (botManager) botManager.notifyError('/forgot-password', error.message);
    req.session.errorMsg = 'Gagal memproses pesan email.';
    res.redirect('/forgot-password');
  }
});

app.get('/reset-password/:token', async (req, res) => {
  try {
    const user = await User.findOne({ resetPasswordToken: req.params.token, resetPasswordExpires: { $gt: Date.now() } });
    if (!user) { req.session.errorMsg = 'Token reset password tidak valid atau sudah kedaluwarsa (berlaku 30 menit).'; return res.redirect('/forgot-password'); }
    res.render('reset_password', { token: req.params.token });
  } catch (error) { res.redirect('/login'); }
});
app.post('/reset-password/:token', async (req, res) => {
  try {
    const user = await User.findOne({ resetPasswordToken: req.params.token, resetPasswordExpires: { $gt: Date.now() } });
    if (!user) { req.session.errorMsg = 'Token reset password tidak valid atau sudah kedaluwarsa.'; return res.redirect('/forgot-password'); }
    const { password, confirmPassword } = req.body;
    if (password !== confirmPassword) { req.session.errorMsg = 'Password dan konfirmasi password tidak cocok.'; return res.redirect(`/reset-password/${req.params.token}`); }
    user.password = hashPassword(password);
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();
    req.session.successMsg = 'Password berhasil diubah. Silakan login dengan password baru.';
    res.redirect('/login');
  } catch (error) { req.session.errorMsg = 'Gagal mereset password.'; res.redirect(`/reset-password/${req.params.token}`); }
});

app.get('/logout', (req, res) => { req.session.destroy(); res.redirect('/login'); });

// ~~~~~~~~ Dashboard User
app.get('/dashboard', isAuth, async (req, res) => {
  if (req.session.userRole === 'admin') return res.redirect('/admin/dashboard');
  const userId = req.session.userId;
  const user = res.locals.user;
  const totalDeposit = (await Transaction.aggregate([
    { $match: { userId: user._id, type: 'deposit', status: 'paid' } },
    { $group: { _id: null, total: { $sum: '$amount' } } }
  ]))[0]?.total || 0;
  const totalWithdraw = (await Transaction.aggregate([
    { $match: { userId: user._id, type: 'withdraw', status: 'success' } },
    { $group: { _id: null, total: { $sum: '$amount' } } }
  ]))[0]?.total || 0;
  const recentTrx = await Invoice.find({ userId: user._id }).sort({ createdAt: -1 }).lean();
  const apiKeys = await ApiKey.find({ userId }).lean();
  res.render('dashboard', { user, totalDeposit, totalWithdraw, recentTrx, apiKeys });
});

// ~~~~~~~~ Profile
app.get('/profile', isAuth, async (req, res) => {
  const apiKeys = await ApiKey.find({ userId: req.session.userId }).lean();
  res.render('profile', { apiKeys });
});
app.post('/profile', isAuth, async (req, res) => {
  const { email, newPassword } = req.body;
  try {
    const upd = { email };
    if (newPassword && newPassword.trim()) upd.password = hashPassword(newPassword);
    await User.findByIdAndUpdate(req.session.userId, upd);
    req.session.successMsg = 'Profil berhasil diperbarui';
    res.redirect('/profile');
  } catch (err) {
    if (err.code === 11000) req.session.errorMsg = 'Email sudah digunakan oleh pengguna lain';
    else req.session.errorMsg = 'Gagal memperbarui profil';
    if (botManager) botManager.notifyError('/profile', err.message);
    res.redirect('/profile');
  }
});
app.post('/api/user/api-key/regenerate', isAuth, async (req, res) => {
  await ApiKey.deleteMany({ userId: req.session.userId });
  const key = generateApiKey();
  try {
    await createWithRetry(ApiKey, { userId: req.session.userId, key });
    res.json({ apiKey: key });
  } catch (err) {
    if (botManager) botManager.notifyError('/api/user/api-key/regenerate', err.message);
    res.status(500).json({ error: 'Gagal membuat API key' });
  }
});

// ~~~~~~~~ Deposit
app.get('/deposit', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const deposits = await Transaction.find({ userId: req.session.userId, type: 'deposit' }).sort({ createdAt: -1 }).lean();
  const invoices = await Invoice.find({ userId: req.session.userId }).sort({ createdAt: -1 }).lean();
  res.render('deposit', { deposits, invoices, minDeposit: settings.minDeposit });
});

async function createInvoiceForUser(userId, amount, settings) {
  if (!settings) settings = await getSettings();
  if (isNaN(amount) || amount < settings.minDeposit) throw new Error(`Minimal deposit adalah Rp ${settings.minDeposit.toLocaleString('id-ID')}`);
  const oneDayAgo = new Date(Date.now() - 30 * 60 * 1000); // 30 menit
  const lockedInvoices = await Invoice.find({
    $or: [{ status: 'pending' }, { status: 'paid', createdAt: { $gte: oneDayAgo } }]
  }).select('fee');
  const usedFees = lockedInvoices.map(i => Number(i.fee)).filter(f => !isNaN(f));
  // 1. Cek ketersediaan fee dalam rentang default (1 .. maxFee)
let availableFees = [];
for (let i = 1; i <= settings.maxFee; i++) {
  if (!usedFees.includes(i)) availableFees.push(i);
}

// 2. Jika penuh, perluas secara bertahap hingga maxFee+100
if (availableFees.length === 0) {
  const maxExtension = settings.maxFee + 100;
  for (let i = settings.maxFee + 1; i <= maxExtension; i++) {
    if (!usedFees.includes(i)) {
      availableFees.push(i);
      break; // hentikan setelah menemukan satu fee yang kosong
    }
  }
}

// 3. Jika setelah perluasan masih tetap kosong, baru tolak
if (availableFees.length === 0) {
  throw new Error('Kode unik deposit sedang penuh. Silakan coba lagi beberapa menit.');
}

const fee = availableFees[Math.floor(Math.random() * availableFees.length)];
  const total = amount + fee;
  const expiredMinutes = settings.qrisExpiredMinutes || 30;
  const expiredAt = new Date(Date.now() + expiredMinutes * 60 * 1000);
  const invoice = await createWithRetry(Invoice, {
    userId, amount, fee, total, trxid: null, qris_image: '', expiredAt, status: 'pending'
  });

  // ===== PEMILIHAN PROVIDER =====
  let qrisImage, trxid;
  if (settings.paymentGateway === 'orderkuota') {
    if (!settings.orderkuotaDomain || !settings.orderkuotaApiKey || !settings.orderkuotaUsername || !settings.orderkuotaToken) {
      await Invoice.findByIdAndDelete(invoice._id);
      throw new Error('Konfigurasi Orderkuota belum lengkap. Hubungi admin.');
    }
    const url = `https://${settings.orderkuotaDomain}/?action=createpayment&apikey=${settings.orderkuotaApiKey}&username=${settings.orderkuotaUsername}&amount=${total}&token=${settings.orderkuotaToken}`;
    try {
      const resp = await axios.get(url);
      const data = resp.data;
      if (!data.status) {
        await Invoice.findByIdAndDelete(invoice._id);
        throw new Error('Gagal membuat QRIS via Orderkuota');
      }
      qrisImage = data.result.qris_image;
      trxid = data.result.trxid;
    } catch (e) {
      await Invoice.findByIdAndDelete(invoice._id);
      throw new Error('Gagal menghubungi Orderkuota: ' + e.message);
    }
  } else {
    // Default Gopay Merchant
    if (!settings.gopayToken || !settings.gopayStaticQr) {
      await Invoice.findByIdAndDelete(invoice._id);
      throw new Error('Konfigurasi Payment Gateway belum lengkap.');
    }
    const gopayBase = settings.gopayDomain || 'gomerch.vercel.app';
    const apiUrl = `https://${gopayBase}/api/qris/create?amount=${total}&static_qr=${encodeURIComponent(settings.gopayStaticQr)}`;
    try {
      const data = await callGopayApiWithRetry(apiUrl);
      if (!data.success) { await Invoice.findByIdAndDelete(invoice._id); throw new Error('Gagal membuat QRIS'); }
      qrisImage = data.image_url;
      trxid = invoice._id;
    } catch (e) { await Invoice.findByIdAndDelete(invoice._id); throw e; }
  }

  invoice.qris_image = qrisImage;
  invoice.trxid = trxid;
  await invoice.save();
  await createWithRetry(Transaction, {
    userId, type: 'deposit', amount, fee, status: 'pending', reference: invoice._id.toString(), qris_image: qrisImage, expiredAt
  });
  return invoice;
}

app.post('/invoice/create', isAuth, async (req, res) => {
  try {
    const amount = parseInt(req.body.amount);
    const settings = res.locals.settings;
    const invoice = await createInvoiceForUser(req.session.userId, amount, settings);
    return res.json({
      reference: invoice._id.toString(), amount: invoice.amount, fee: invoice.fee,
      total: invoice.total, qris_image: invoice.qris_image, createdAt: invoice.createdAt,
      expiredAt: invoice.expiredAt, status: 'pending'
    });
  } catch (e) {
    console.error('Create invoice error:', e.message);
    if (botManager) botManager.notifyError('/invoice/create', e.message);
    return res.status(400).json({ error: e.message });
  }
});

// ~~~~~~~~ WITHDRAW MANUAL
app.get('/withdraw', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const instantMethods = (settings.instantWithdrawMethods || []).filter(m => m.active);
  const withdrawals = await Withdrawal.find({ userId: req.session.userId }).sort({ createdAt: -1 }).lean();
  res.render('withdraw', { settings, withdrawals, withdrawMethods: settings.withdrawMethods || [], instantMethods });
});

app.post('/withdraw/request', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const { amount, methodName, accountNumber } = req.body; 

  if (!methodName || !accountNumber) {
    req.session.errorMsg = 'Harap lengkapi metode dan nomor tujuan.';
    return res.redirect('/withdraw');
  }

  const amt = parseInt(amount);
  const selectedMethod = (settings.withdrawMethods || []).find(m => m.name === methodName);
  if (!selectedMethod) {
    req.session.errorMsg = 'Metode penarikan tidak valid.';
    return res.redirect('/withdraw');
  }

// Hanya gunakan min dari metode (tidak ada fallback ke global)
const minAmount = selectedMethod.min || 0;
if (minAmount > 0 && (isNaN(amt) || amt < minAmount)) {
  req.session.errorMsg = `Minimal penarikan untuk ${selectedMethod.name} adalah Rp ${minAmount.toLocaleString('id-ID')}`;
  return res.redirect('/withdraw');
}

// Validasi maksimal penarikan (1 juta atau dari metode)
const maxAmount = selectedMethod.max || 1000000; // default 1 juta
if (maxAmount > 0 && !isNaN(amt) && amt > maxAmount) {
  req.session.errorMsg = `Maksimal penarikan untuk ${selectedMethod.name} adalah Rp ${maxAmount.toLocaleString('id-ID')}`;
  return res.redirect('/withdraw');
}

  if (isNaN(amt) || amt <= 0) {
    req.session.errorMsg = 'Nominal penarikan tidak valid.';
    return res.redirect('/withdraw');
  }

  const fee = selectedMethod.fee || 0;
  const totalDeduct = amt + fee;

  const updatedUser = await User.findOneAndUpdate(
    { _id: req.session.userId, balance: { $gte: totalDeduct } },
    { $inc: { balance: -totalDeduct } },
    { new: true }
  );
  if (!updatedUser) {
    req.session.errorMsg = 'Saldo tidak cukup (termasuk biaya admin Rp ' + fee.toLocaleString('id-ID') + ')';
    return res.redirect('/withdraw');
  }

  try {
    const ref = 'W' + Date.now().toString(36).toUpperCase();
    const wd = await createWithRetry(Withdrawal, {
      userId: req.session.userId,
      amount: amt,
      fee,
      method: selectedMethod.name,
      accountNumber
    });
    await createWithRetry(Transaction, {
      userId: req.session.userId,
      type: 'withdraw',
      amount: amt,
      fee,
      status: 'pending',
      reference: ref,
      method: selectedMethod.name,
      accountNumber
    });

    if (botManager) {
      const user = await User.findById(req.session.userId).lean();
      botManager.notifyWithdrawRequest(wd, user);
    }
    req.session.successMsg = 'Penarikan berhasil diajukan dan sedang diproses.';
  } catch (err) {
    await User.findByIdAndUpdate(req.session.userId, { $inc: { balance: totalDeduct } });
    req.session.errorMsg = 'Gagal memproses penarikan. Silakan coba lagi.';
    console.error(err);
    if (botManager) botManager.notifyError('/withdraw/request', err.message);
  }
  res.redirect('/withdraw');
});

// ~~~~~~~~ WITHDRAW INSTAN
app.post('/withdraw/instant', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const { amount, methodCode, destination } = req.body;
  if (!methodCode || !destination || !amount) { req.session.errorMsg = 'Harap lengkapi semua field.'; return res.redirect('/withdraw'); }
  const amt = parseInt(amount);
  if (isNaN(amt) || amt <= 0) { req.session.errorMsg = 'Nominal tidak valid.'; return res.redirect('/withdraw'); }
  const method = (settings.instantWithdrawMethods || []).find(m => m.code === methodCode && m.active);
  if (!method) { req.session.errorMsg = 'Metode withdraw instan tidak tersedia.'; return res.redirect('/withdraw'); }
if (amt < method.minAmount) { 
  req.session.errorMsg = `Minimal penarikan instan ${method.name} adalah Rp ${method.minAmount.toLocaleString('id-ID')}`; 
  return res.redirect('/withdraw'); 
}
const maxInstant = method.maxAmount || 1000000;
if (amt > maxInstant) {
  req.session.errorMsg = `Maksimal penarikan instan ${method.name} adalah Rp ${maxInstant.toLocaleString('id-ID')}`;
  return res.redirect('/withdraw');
}
  const fee = method.fee || 0;
  const totalDeduct = amt + fee;
  if (!settings.h2hIdMerchant || !settings.h2hPin || !settings.h2hPassword) { req.session.errorMsg = 'Fitur withdraw instan belum dikonfigurasi oleh admin.'; return res.redirect('/withdraw'); }
  const updatedUser = await User.findOneAndUpdate(
    { _id: req.session.userId, balance: { $gte: totalDeduct } },
    { $inc: { balance: -totalDeduct } },
    { new: true }
  );
  if (!updatedUser) { req.session.errorMsg = 'Saldo tidak cukup (termasuk biaya admin Rp ' + fee.toLocaleString('id-ID') + ')'; return res.redirect('/withdraw'); }
  const ref = 'W' + Date.now().toString(36).toUpperCase();
  const h2hUrl = `https://h2h.okeconnect.com/trx?memberID=${settings.h2hIdMerchant}&product=${method.code}&dest=${destination}&qty=${amt}&refID=${ref}&pin=${settings.h2hPin}&password=${settings.h2hPassword}`;
  try {
    await axios.get(h2hUrl, { timeout: 15000 });
    const wd = await createWithRetry(Withdrawal, {
      userId: req.session.userId, amount: amt, fee, method: method.name, methodCode: method.code,
      accountNumber: destination, instant: true, destination, h2hRefId: ref, status: 'pending'
    });
    await createWithRetry(Transaction, {
      userId: req.session.userId, type: 'withdraw', amount: amt, fee, status: 'pending', reference: ref,
      method: method.name, accountNumber: destination, instant: true
    });
    req.session.successMsg = 'Permintaan withdraw instan sedang diproses. Silakan cek status secara berkala.';
  } catch (err) {
    await User.findByIdAndUpdate(req.session.userId, { $inc: { balance: totalDeduct } });
    console.error('Withdraw instan request error:', err.message);
    req.session.errorMsg = 'Gagal mengirim permintaan withdraw instan. Saldo dikembalikan.';
    if (botManager) botManager.notifyError('/withdraw/instant (request)', err.message);
  }
  res.redirect('/withdraw');
});

// ~~~~~~~~ HELPER INSTANT WITHDRAW (CHECKER)
async function checkInstantWithdrawals() {
  try {
    const settings = await getSettings();
    if (!settings.h2hIdMerchant) return;
    const pendingInstants = await Withdrawal.find({ instant: true, status: 'pending' });
    for (const wd of pendingInstants) {
      const h2hUrl = `https://h2h.okeconnect.com/trx?memberID=${settings.h2hIdMerchant}&product=${wd.methodCode}&dest=${wd.destination}&qty=${wd.amount}&refID=${wd.h2hRefId}&pin=${settings.h2hPin}&password=${settings.h2hPassword}`;
      try {
        const response = await axios.get(h2hUrl, { timeout: 15000 });
        const responseText = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
        if (/status Sukses/i.test(responseText)) return succeedInstantWithdrawal(wd, "Berhasil Dikirim");
        if (/saldo kamu kurang/i.test(responseText)) return rejectInstantWithdrawal(wd, "Terjadi Kesalahan Sistem");
        if (/Nomor HP tidak benar/i.test(responseText)) return rejectInstantWithdrawal(wd, "Nomor Ewallet Tidak Valid");
        if (/Gagal/i.test(responseText)) return rejectInstantWithdrawal(wd, "Terjadi Kesalahan Sistem");
      } catch (err) { console.error(`Cek status WD instan ${wd._id} gagal:`, err.message); }
    }
  } catch (err) { console.error('checkInstantWithdrawals error:', err); if (botManager) botManager.notifyError('checkInstantWithdrawals', err.message); }
}

async function succeedInstantWithdrawal(wd, responseText) {
  wd.status = 'success'; wd.completedAt = new Date(); wd.h2hResponse = responseText; await wd.save();
  await Transaction.updateOne({ userId: wd.userId, type: 'withdraw', status: 'pending', reference: wd.h2hRefId }, { status: 'success', completedAt: new Date(), adminNote: responseText });
  if (botManager) { const user = await User.findById(wd.userId).lean(); botManager.notifyInstantWithdraw(wd, user); }
}
async function rejectInstantWithdrawal(wd, reason) {
  wd.status = 'rejected'; wd.adminNote = reason; wd.completedAt = new Date(); await wd.save();
  await User.findByIdAndUpdate(wd.userId, { $inc: { balance: wd.amount + wd.fee } });
  await Transaction.updateOne({ userId: wd.userId, type: 'withdraw', status: 'pending', reference: wd.h2hRefId }, { status: 'rejected', adminNote: reason, completedAt: new Date() });
  if (botManager) { const user = await User.findById(wd.userId).lean(); botManager.notifyInstantWithdraw(wd, user, true, reason); }
}

// ~~~~~~~~ CHECKER MUTASI (DUKUNG DUA PROVIDER)
let checkerInterval;
async function checkMutasi() {
  try {
    const settings = await getSettings();
    const expiredMinutes = settings.qrisExpiredMinutes || 30;
    const now = new Date();
    await checkInstantWithdrawals();

    // 1. Tandai expired
    const expiredInvoices = await Invoice.find({ status: 'pending', expiredAt: { $lt: now } });
    for (const inv of expiredInvoices) {
      inv.status = 'expired'; await inv.save();
      await Transaction.updateOne({ reference: inv._id.toString(), type: 'deposit', status: 'pending' }, { status: 'expired' });
    }

    const pendingInvoices = await Invoice.find({ status: 'pending' }).lean();

    if (settings.paymentGateway === 'orderkuota') {
      // === ORDERKUOTA MUTASI ===
      if (!settings.orderkuotaDomain || !settings.orderkuotaApiKey) return;
      const mutasiUrl = `https://${settings.orderkuotaDomain}/?action=mutasiqr&apikey=${settings.orderkuotaApiKey}&username=${settings.orderkuotaUsername}&token=${settings.orderkuotaToken}`;
      try {
        const resp = await axios.get(mutasiUrl);
        const data = resp.data;
        if (!data.status || !data.result || !data.result.success || !Array.isArray(data.result.results)) return;
        const results = data.result.results;
        const usedMutationIds = await Invoice.find({ mutationId: { $ne: null } }).distinct('mutationId');
        const availableMutations = results.filter(tx => tx.status === 'IN' && !usedMutationIds.includes(String(tx.id)));

        for (const inv of pendingInvoices) {
          const matchedMutation = availableMutations.find(tx => {
            const nominal = parseInt(String(tx.kredit).replace(/\./g, ''));
            if (nominal !== inv.total) return false;
            const rawDateString = tx.tanggal || tx.created_at || tx.createdAt || tx.date || tx.datetime || tx.tanggal;
            if (!rawDateString) return false;
            let mutationTime;
            if (rawDateString.includes('/')) {
              const [datePart, timePart] = rawDateString.split(' ');
              const [day, month, year] = datePart.split('/');
              mutationTime = new Date(`${year}-${month}-${day}T${timePart}+07:00`);
            } else {
              mutationTime = new Date(rawDateString);
            }
            if (isNaN(mutationTime.getTime())) return false;
            const diffMinutes = Math.abs(mutationTime.getTime() - inv.createdAt.getTime()) / 1000 / 60;
            return diffMinutes <= expiredMinutes;
          });
          if (!matchedMutation) continue;

          await Invoice.findByIdAndUpdate(inv._id, { status: 'paid', mutationId: String(matchedMutation.id) });
          await User.findByIdAndUpdate(inv.userId, { $inc: { balance: inv.amount } });
          await Transaction.updateOne({ reference: inv._id.toString(), type: 'deposit', status: 'pending' }, { status: 'paid' });
          if (botManager) { const user = await User.findById(inv.userId).lean(); if (user) botManager.notifyDeposit(inv, user); }
          const idx = availableMutations.findIndex(tx => String(tx.id) === String(matchedMutation.id));
          if (idx !== -1) availableMutations.splice(idx, 1);
        }
      } catch (err) {
        console.error('Orderkuota Mutasi error:', err.message);
        if (botManager) botManager.notifyError('checkMutasi (orderkuota)', err.message);
      }

    } else {
      // === GOPAY MERCHANT ===
      if (!settings.gopayToken) return;
      const gopayBase = settings.gopayDomain || 'gomerch.vercel.app';
      const apiUrl = `https://${gopayBase}/api/history?token=${encodeURIComponent(settings.gopayToken)}`;
      try {
        const data = await callGopayApiWithRetry(apiUrl);
        if (!data.success || !Array.isArray(data.data)) return;
        const mutations = data.data.filter(tx => tx.status === 'success');
        const usedMutationIds = await Invoice.find({ mutationId: { $ne: null } }).distinct('mutationId');
        const availableMutations = mutations.filter(tx => !usedMutationIds.includes(String(tx.id)));
        for (const inv of pendingInvoices) {
          const match = availableMutations.find(tx => {
            if (tx.amount !== inv.total) return false;
            const txTime = new Date(tx.time);
            if (isNaN(txTime.getTime())) return false;
            const diffMinutes = Math.abs(txTime.getTime() - inv.createdAt.getTime()) / 1000 / 60;
            return diffMinutes <= expiredMinutes;
          });
          if (!match) continue;
          await Invoice.findByIdAndUpdate(inv._id, { status: 'paid', mutationId: String(match.id) });
          await User.findByIdAndUpdate(inv.userId, { $inc: { balance: inv.amount } });
          await Transaction.updateOne({ reference: inv._id.toString(), type: 'deposit', status: 'pending' }, { status: 'paid' });
          if (botManager) { const user = await User.findById(inv.userId).lean(); if (user) botManager.notifyDeposit(inv, user); }
          const idx = availableMutations.findIndex(tx => String(tx.id) === String(match.id));
          if (idx !== -1) availableMutations.splice(idx, 1);
        }
      } catch (err) { console.error('Mutasi error:', err.response?.data || err.message); if (botManager) botManager.notifyError('checkMutasi', err.response?.data?.error || err.message); }
    }
  } catch (err) { console.error('Mutasi error:', err.response?.data || err.message); if (botManager) botManager.notifyError('checkMutasi global', err.message); }
}

async function updateStatsOnStartup() {
  const [depositAgg, withdrawAgg, totalUsers, totalTrx, balanceAgg] = await Promise.all([
    Transaction.aggregate([{ $match: { type: 'deposit', status: 'paid' } }, { $group: { _id: null, totalAmount: { $sum: '$amount' }, totalFee: { $sum: '$fee' } } }]),
    Transaction.aggregate([{ $match: { type: 'withdraw', status: 'success' } }, { $group: { _id: null, totalAmount: { $sum: '$amount' }, totalFee: { $sum: '$fee' } } }]),
    User.countDocuments({ role: 'user' }),
    Transaction.countDocuments(),
    User.aggregate([{ $match: { role: 'user' } }, { $group: { _id: null, totalBalance: { $sum: '$balance' } } }])
  ]);
  await Stats.deleteMany({});
  await Stats.create({
    totalDepositAmount: depositAgg[0]?.totalAmount || 0,
    totalDepositFee: depositAgg[0]?.totalFee || 0,
    totalWithdrawAmount: withdrawAgg[0]?.totalAmount || 0,
    totalWithdrawFee: withdrawAgg[0]?.totalFee || 0,
    totalUsers,
    totalTransactions: totalTrx,
    totalUserBalance: balanceAgg[0]?.totalBalance || 0
  });
}

// ~~~~~~~~ PUBLIC PAYMENT PAGE
app.get('/payment/:id', async (req, res) => {
  try {
    const invoice = await Invoice.findById(req.params.id).populate('userId', 'username');
    if (!invoice) {
      return res.status(404).send('Invoice tidak ditemukan');
    }
    const settings = await getSettings();
    res.render('payment', { invoice, settings });
  } catch (err) {
    console.error('Payment page error:', err);
    res.status(500).send('Terjadi kesalahan server');
  }
});

app.get('/payment/status/:id', async (req, res) => {
  try {
    const invoice = await Invoice.findById(req.params.id);
    if (!invoice) {
      return res.status(404).json({ error: 'Invoice tidak ditemukan' });
    }
    res.json({ status: invoice.status });
  } catch (err) {
    console.error('Payment status error:', err);
    res.status(500).json({ error: 'Terjadi kesalahan server' });
  }
});

function startChecker() {
  if (checkerInterval) clearInterval(checkerInterval);
  getSettings().then(s => { checkerInterval = setInterval(checkMutasi, s.checkInterval * 1000); checkMutasi(); });
}
setTimeout(async () => { await updateStatsOnStartup(); startChecker(); }, 2000);

// ~~~~~~~~ ADMIN ROUTES
app.get('/admin/dashboard', isAuth, isAdmin, async (req, res) => {
  const stats = await computeStats();
  res.render('admin_dashboard', stats);
});

app.get('/admin/users', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  const filter = { role: 'user' };
  if (search) filter.$or = [{ email: { $regex: search, $options: 'i' } }, { username: { $regex: search, $options: 'i' } }];
  const users = await User.find(filter).sort({ createdAt: -1 }).lean();
  res.render('admin_users', { users, search });
});
app.get('/admin/users/:id/edit', isAuth, isAdmin, async (req, res) => {
  const targetUser = await User.findById(req.params.id).lean();
  if (!targetUser) return res.status(404).send('Tidak ditemukan');
  res.render('admin_user_edit', { users: targetUser });
});
app.post('/admin/users/:id/edit', isAuth, isAdmin, async (req, res) => {
  const { username, email, password, balance, suspended } = req.body;
  if (username) {
    if (!/^[a-zA-Z0-9]+$/.test(username)) { req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)'; return res.redirect(`/admin/users/${req.params.id}/edit`); }
    if (username.length > 15) { req.session.errorMsg = 'Username maksimal 15 karakter'; return res.redirect(`/admin/users/${req.params.id}/edit`); }
  }
  const upd = { username: username?.toLowerCase(), email, balance: parseInt(balance) || 0, suspended: suspended === 'on' };
  if (!upd.username) delete upd.username;
  if (password && password.trim()) upd.password = hashPassword(password);
  try {
    await User.findByIdAndUpdate(req.params.id, upd, { runValidators: true });
    req.session.successMsg = 'Data pengguna berhasil diperbarui';
    res.redirect('/admin/users');
  } catch (err) {
    if (err.code === 11000) req.session.errorMsg = 'Username atau email sudah digunakan oleh pengguna lain';
    else if (err.name === 'ValidationError') req.session.errorMsg = Object.values(err.errors).map(e => e.message).join(', ');
    else req.session.errorMsg = 'Gagal memperbarui data pengguna';
    if (botManager) botManager.notifyError('/admin/users/edit', err.message);
    res.redirect(`/admin/users/${req.params.id}/edit`);
  }
});
app.post('/admin/users/:id/delete', isAuth, isAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const userToDelete = await User.findById(userId);
    if (!userToDelete) { req.session.errorMsg = 'User tidak ditemukan.'; return res.redirect('/admin/users'); }
    if (userToDelete.role === 'admin') { req.session.errorMsg = 'Tidak dapat menghapus akun admin.'; return res.redirect('/admin/users'); }
    await Invoice.deleteMany({ userId });
    await Transaction.deleteMany({ userId });
    await Withdrawal.deleteMany({ userId });
    await ApiKey.deleteMany({ userId });
    await User.findByIdAndDelete(userId);
    req.session.successMsg = 'User berhasil dihapus beserta seluruh data terkait.';
    res.redirect('/admin/users');
  } catch (err) { console.error(err); if (botManager) botManager.notifyError('/admin/users/delete', err.message); req.session.errorMsg = 'Gagal menghapus user.'; res.redirect('/admin/users'); }
});
// POST - Edit status deposit (via modal, returns JSON)
app.post('/admin/transactions/:id/edit', isAuth, isAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    if (!status) {
      return res.status(400).json({ success: false, error: 'Status baru diperlukan.' });
    }

    const transaction = await Transaction.findById(req.params.id);
    if (!transaction || transaction.type !== 'deposit') {
      return res.status(404).json({ success: false, error: 'Transaksi deposit tidak ditemukan.' });
    }

    const prevStatus = transaction.status;
    
    // Validasi transisi status yang diizinkan
    const allowedMap = {
      pending: ['paid', 'expired'],
      paid: ['expired'],
      expired: ['paid']
    };
    
    const allowedStatuses = allowedMap[prevStatus] || [];
    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({ success: false, error: 'Perubahan status tidak diizinkan.' });
    }

    const userId = transaction.userId;
    const amount = transaction.amount;
    const reference = transaction.reference;

    // Logika sinkronisasi saldo dan invoice
    if (status === 'paid') {
      // Menjadi paid: tambah saldo (baik dari pending atau expired)
      // Cegah double add jika sebelumnya sudah paid (tidak mungkin karena validasi, tapi aman)
      if (prevStatus !== 'paid') {
        await User.findByIdAndUpdate(userId, { $inc: { balance: amount } });
      }
      if (reference) {
        await Invoice.findOneAndUpdate(
          { _id: reference, userId },
          { status: 'paid' }
        );
      }
    } else if (status === 'expired') {
      // Menjadi expired: 
      if (prevStatus === 'paid') {
        // Dari paid → expired: kurangi saldo
        await User.findByIdAndUpdate(userId, { $inc: { balance: -amount } });
      }
      // Jika dari pending → expired: tidak ada perubahan saldo
      if (reference) {
        await Invoice.findOneAndUpdate(
          { _id: reference, userId },
          { status: 'expired' }
        );
      }
    }

    // Update transaksi
    transaction.status = status;
    transaction.completedAt = (status === 'paid' || status === 'expired') ? new Date() : undefined;
    await transaction.save();

    return res.json({ success: true, message: `Status berhasil diubah menjadi ${status}.` });
  } catch (err) {
    console.error('Edit deposit status error:', err);
    if (botManager) botManager.notifyError('/admin/transactions/edit', err.message);
    return res.status(500).json({ success: false, error: 'Terjadi kesalahan server.' });
  }
});
app.get('/admin/withdraw', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let filter = { instant: false };
  if (search) {
    const users = await User.find({ $or: [{ email: { $regex: search, $options: 'i' } }, { username: { $regex: search, $options: 'i' } }] }).select('_id');
    filter.userId = { $in: users.map(u => u._id) };
  }
  const withdrawals = await Withdrawal.find(filter).populate('userId', 'username email').sort({ createdAt: -1 }).lean();
  res.render('admin_withdraw', { withdrawals, search });
});
app.post('/admin/withdraw/success/:id', isAuth, isAdmin, async (req, res) => {
  const wd = await Withdrawal.findById(req.params.id);
  if (wd && wd.status === 'pending' && !wd.instant) {
    wd.status = 'success'; wd.completedAt = new Date(); await wd.save();
    await Transaction.updateOne({ userId: wd.userId, type: 'withdraw', status: 'pending', reference: { $regex: /^W/ } }, { status: 'success', completedAt: new Date() });
    req.session.successMsg = 'Penarikan berhasil disetujui.';
  }
  res.redirect('/admin/withdraw');
});
app.post('/admin/withdraw/reject/:id', isAuth, isAdmin, async (req, res) => {
  const wd = await Withdrawal.findById(req.params.id);
  if (wd && wd.status === 'pending' && !wd.instant) {
    wd.status = 'rejected'; wd.adminNote = req.body.note || ''; wd.completedAt = new Date(); await wd.save();
    await User.findByIdAndUpdate(wd.userId, { $inc: { balance: wd.amount + wd.fee } });
    await Transaction.updateOne({ userId: wd.userId, type: 'withdraw', status: 'pending', reference: { $regex: /^W/ } }, { status: 'rejected', adminNote: req.body.note || '', completedAt: new Date() });
    req.session.successMsg = 'Penarikan ditolak dan saldo dikembalikan.';
  }
  res.redirect('/admin/withdraw');
});

app.get('/admin/transactions', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let filter = {};
  if (search) {
    const users = await User.find({ $or: [{ email: { $regex: search, $options: 'i' } }, { username: { $regex: search, $options: 'i' } }] }).select('_id');
    filter = { $or: [{ userId: { $in: users.map(u => u._id) } }, { reference: { $regex: search, $options: 'i' } }] };
  }
  const transactions = await Transaction.find(filter).populate('userId', 'username email').sort({ createdAt: -1 }).lean();
  res.render('admin_transactions', { transactions, search });
});

app.get('/admin/account', isAuth, isAdmin, async (req, res) => {
  const admin = await User.findById(req.session.userId).lean();
  res.render('admin_account', { admin });
});
app.post('/admin/account', isAuth, isAdmin, async (req, res) => {
  const { username, password, newPassword } = req.body;
  const admin = await User.findById(req.session.userId).lean();
  if (!password || !verifyPassword(password, admin.password)) { req.session.errorMsg = 'Password saat ini salah'; return res.redirect('/admin/account'); }
  if (username && username !== admin.username) {
    if (!/^[a-zA-Z0-9]+$/.test(username)) { req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)'; return res.redirect('/admin/account'); }
    if (username.length > 15) { req.session.errorMsg = 'Username maksimal 15 karakter'; return res.redirect('/admin/account'); }
    const exist = await User.findOne({ username: username.toLowerCase(), _id: { $ne: admin._id } });
    if (exist) { req.session.errorMsg = 'Username sudah digunakan oleh pengguna lain'; return res.redirect('/admin/account'); }
  }
  try {
    const update = {};
    if (username && username !== admin.username) update.username = username.toLowerCase();
    if (newPassword && newPassword.trim()) update.password = hashPassword(newPassword);
    if (Object.keys(update).length > 0) { await User.findByIdAndUpdate(req.session.userId, update); req.session.successMsg = 'Data akun berhasil diperbarui'; }
    else req.session.errorMsg = 'Tidak ada perubahan yang dilakukan';
  } catch (e) { if (botManager) botManager.notifyError('/admin/account', e.message); req.session.errorMsg = 'Gagal memperbarui akun'; }
  res.redirect('/admin/account');
});

app.post('/admin/settings/withdraw-methods', isAuth, isAdmin, async (req, res) => {
  try {
    const { withdrawMethods } = req.body;
    if (!Array.isArray(withdrawMethods) || withdrawMethods.length === 0) return res.status(400).json({ success: false, error: 'Data tidak valid' });
    const cleaned = withdrawMethods
      .filter(m => m.name && typeof m.name === 'string' && m.name.trim() !== '')
      .map(m => ({
        name: m.name.trim(),
        fee: typeof m.fee === 'number' && !isNaN(m.fee) ? m.fee : 0,
        min: typeof m.min === 'number' && !isNaN(m.min) && m.min > 0 ? m.min : 0
      }));
    if (cleaned.length === 0) return res.status(400).json({ success: false, error: 'Minimal satu metode harus valid' });
    await Setting.updateOne({}, { withdrawMethods: cleaned });
    return res.json({ success: true });
  } catch (err) { console.error(err); if (botManager) botManager.notifyError('/admin/settings/withdraw-methods', err.message); return res.status(500).json({ success: false, error: 'Gagal menyimpan metode withdraw' }); }
});

app.post('/admin/settings/reset', isAuth, isAdmin, async (req, res) => {
  try {
    await User.deleteMany({ role: 'user' });
    await Invoice.deleteMany({});
    await Transaction.deleteMany({});
    await Withdrawal.deleteMany({});
    await ApiKey.deleteMany({});
    await Stats.deleteMany({});
    await Stats.create({ totalDepositAmount: 0, totalDepositFee: 0, totalWithdrawAmount: 0, totalWithdrawFee: 0, totalUsers: 0, totalTransactions: 0, totalUserBalance: 0 });
    req.session.successMsg = 'Database berhasil direset. Semua data pengguna, invoice, transaksi, dan withdrawal telah dihapus.';
  } catch (error) { console.error('Reset database error:', error); if (botManager) botManager.notifyError('/admin/settings/reset', error.message); req.session.errorMsg = 'Gagal mereset database. Silakan coba lagi.'; }
  res.redirect('/admin/settings');
});

// ~~~~~~~~ TOGGLE BOT TELEGRAM
app.post('/admin/settings/toggle-bot', isAuth, isAdmin, async (req, res) => {
  try {
    const settings = await Setting.findOne();
    if (!settings.telegramBotToken || !settings.telegramOwnerId) return res.json({ success: false, error: 'Token Bot atau Owner ID belum diisi.' });
    const newStatus = !settings.telegramBotEnabled;
    settings.telegramBotEnabled = newStatus;
    await settings.save();
    if (botManager) await botManager.updateSettings(settings);
    const botRunning = botManager ? botManager.isRunning() : false;
    return res.json({ success: true, botRunning, message: botRunning ? 'Bot berhasil disambungkan.' : 'Bot berhasil diputuskan.' });
  } catch (err) { console.error('Toggle bot error:', err); if (botManager) botManager.notifyError('/admin/settings/toggle-bot', err.message); return res.json({ success: false, error: 'Gagal mengubah status bot.' }); }
});

app.post('/admin/settings/restart-bot', isAuth, isAdmin, async (req, res) => {
  try {
    if (!botManager) {
      return res.status(500).json({
        success: false,
        message: 'Bot Manager belum diinisialisasi. Harap tunggu beberapa saat.'
      });
    }
    // Restart bot tanpa peduli apakah sedang aktif atau tidak
    await botManager.restartBot();
    return res.json({
      success: true,
      message: '✅ Bot Telegram berhasil direstart.'
    });
  } catch (err) {
    console.error('Gagal restart bot:', err);
    return res.status(500).json({
      success: false,
      message: '❌ Gagal merestart bot: ' + err.message
    });
  }
});

// ~~~~~~~~ ADMIN SETTINGS
app.get('/admin/settings', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  const botStatus = botManager ? (botManager.isRunning() ? 'Running' : 'Stopped') : 'Not initialized';
  res.render('admin_settings', { settings, botStatus });
});

app.post('/admin/settings/instant-withdraw-methods', isAuth, isAdmin, async (req, res) => {
  try {
    const { instantWithdrawMethods } = req.body;
    if (!Array.isArray(instantWithdrawMethods)) return res.status(400).json({ success: false, error: 'Data tidak valid' });
    const cleaned = instantWithdrawMethods.map(m => ({
      name: m.name || '', code: m.code || '', fee: parseInt(m.fee) || 0,
      minAmount: parseInt(m.minAmount) || 10000, active: m.active === true || m.active === 'true' || m.active === 'on'
    })).filter(m => m.name.trim() !== '' && m.code.trim() !== '');
    await Setting.updateOne({}, { instantWithdrawMethods: cleaned });
    return res.json({ success: true });
  } catch (err) { console.error(err); if (botManager) botManager.notifyError('/admin/settings/instant-withdraw-methods', err.message); return res.status(500).json({ success: false, error: 'Gagal menyimpan metode instan' }); }
});

app.post('/admin/settings', isAuth, isAdmin, (req, res, next) => {
  logoUpload.single('logo')(req, res, function(err) {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') req.session.errorMsg = 'Ukuran file logo maksimal 2MB.';
      else if (err.message) req.session.errorMsg = 'Gagal upload logo: ' + err.message;
      else req.session.errorMsg = 'Gagal upload logo.';
      if (botManager) botManager.notifyError('/admin/settings (logo upload)', err.message);
      return res.redirect('/admin/settings');
    }
    next();
  });
}, async (req, res) => {
  let withdrawMethods = [];
  const raw = req.body.withdrawMethodsJson;
  if (raw) {
    try {
      withdrawMethods = JSON.parse(raw);
      if (!Array.isArray(withdrawMethods)) withdrawMethods = [];
    } catch (e) {
      withdrawMethods = [];
    }
  }
  withdrawMethods = withdrawMethods
    .filter(m => m.name && typeof m.name === 'string' && m.name.trim() !== '')
    .map(m => ({
      name: m.name.trim(),
      fee: typeof m.fee === 'number' && !isNaN(m.fee) ? m.fee : 0,
      min: typeof m.min === 'number' && !isNaN(m.min) && m.min > 0 ? m.min : 0
    }));
  if (withdrawMethods.length === 0) {
    withdrawMethods = [
      { name: 'Dana', fee: 1000, min: 10000 },
      { name: 'GoPay', fee: 2000, min: 10000 }
    ];
  }

  let instantWithdrawMethods = [];
  const instantRaw = req.body.instantWithdrawMethodsJson;
  if (instantRaw) {
    try {
      instantWithdrawMethods = JSON.parse(instantRaw);
      if (!Array.isArray(instantWithdrawMethods)) instantWithdrawMethods = [];
    } catch (e) {
      instantWithdrawMethods = [];
    }
  }
  instantWithdrawMethods = instantWithdrawMethods.map(m => ({
    name: m.name || '', code: m.code || '', fee: parseInt(m.fee) || 0,
    minAmount: parseInt(m.minAmount) || 10000, active: m.active === true || m.active === 'true' || m.active === 'on'
  })).filter(m => m.name.trim() !== '' && m.code.trim() !== '');
  if (instantWithdrawMethods.length === 0) instantWithdrawMethods = [
    { name: 'Dana', code: 'BBSD', fee: 1000, minAmount: 10000, active: true },
    { name: 'GoPay', code: 'BBSGOP', fee: 2000, minAmount: 10000, active: true }
  ];

  const parseNumber = (val, def) => { const n = parseInt(val); return isNaN(n) ? def : n; };
  const {
    name, title, description, channelInformation, contactDeveloper, minDeposit, minWithdraw, maxFee,
    checkInterval, smtpUser, smtpPass, qrisExpiredMinutes,
    gopayDomain, gopayToken, gopayStaticQr, gopayRefreshToken,
    // ===== TAMBAHAN =====
    paymentGateway,
    orderkuotaDomain, orderkuotaApiKey, orderkuotaUsername, orderkuotaToken,
    // ===================
    telegramBotToken, telegramOwnerId, telegramBotEnabled,
    h2hIdMerchant, h2hPin, h2hPassword
  } = req.body;

  let logoUrl = req.body.existingLogoUrl || '';
  if (req.file) {
    if (logoUrl && logoUrl.startsWith('/')) {
      const oldPath = path.join(__dirname, 'public', logoUrl);
      if (fs.existsSync(oldPath)) try { fs.unlinkSync(oldPath); } catch (e) { console.error('Gagal menghapus logo lama:', e); }
    }
    logoUrl = '/' + req.file.filename;
  }

  try {
    await Setting.updateOne({}, {
      name, title, description, channelInformation, contactDeveloper,
      minDeposit: parseNumber(minDeposit, 1000), minWithdraw: parseNumber(minWithdraw, 5000),
      maxFee: parseNumber(maxFee, 500),
      checkInterval: parseNumber(checkInterval, 30), smtpUser, smtpPass,
      logoUrl, qrisExpiredMinutes: parseNumber(qrisExpiredMinutes, 30),
      withdrawMethods,
      gopayDomain: gopayDomain || 'gomerch.vercel.app', gopayToken: gopayToken || '',
      gopayStaticQr: gopayStaticQr || '', gopayRefreshToken: gopayRefreshToken || '',
      // ===== TAMBAHAN =====
      paymentGateway: paymentGateway || 'gopaymerchant',
      orderkuotaDomain: orderkuotaDomain || '',
      orderkuotaApiKey: orderkuotaApiKey || '',
      orderkuotaUsername: orderkuotaUsername || '',
      orderkuotaToken: orderkuotaToken || '',
      // ===================
      telegramBotToken: telegramBotToken || '', telegramOwnerId: telegramOwnerId || '',
      telegramBotEnabled: telegramBotEnabled === 'on' || telegramBotEnabled === true,
      h2hIdMerchant: h2hIdMerchant || '', h2hPin: h2hPin || '', h2hPassword: h2hPassword || '',
      instantWithdrawMethods
    });
    const updatedSettings = await Setting.findOne();
    if (botManager) await botManager.updateSettings(updatedSettings);
    startChecker();
    req.session.successMsg = 'Pengaturan berhasil diperbarui.';
  } catch (err) { console.error('Gagal menyimpan pengaturan:', err); if (botManager) botManager.notifyError('/admin/settings (save)', err.message); req.session.errorMsg = 'Gagal menyimpan pengaturan.'; }
  res.redirect('/admin/settings');
});

// ~~~~~~~~ PUBLIC API / DOCS
app.get('/docs', async (req, res) => {
  let userApiKey = '';
  if (req.session.userId) { const key = await ApiKey.findOne({ userId: req.session.userId }); if (key) userApiKey = key.key; }
  res.render('docs', { userApiKey });
});

async function apiAuth(req, res, next) {
  const apiKey = req.headers['x-api-key'] || req.query.api_key || req.query.apikey;
  if (!apiKey) return res.status(401).json({ error: 'API key diperlukan' });
  const keyDoc = await ApiKey.findOne({ key: apiKey });
  if (!keyDoc) return res.status(401).json({ error: 'API key tidak valid' });
  req.apiUser = keyDoc.userId;
  next();
}
app.get('/api/balance', apiAuth, async (req, res) => {
  const user = await User.findById(req.apiUser);
  if (!user) return res.status(404).json({ error: 'User tidak ditemukan' });
  res.json({ balance: user.balance });
});
app.get('/api/invoice', apiAuth, async (req, res) => {
  try {
    const settings = await getSettings();
    const amount = parseInt(req.query.amount);
if (isNaN(amount) || amount < settings.minDeposit || amount > 1_000_000) {
  const message = isNaN(amount)
    ? 'Jumlah deposit tidak valid'
    : amount < settings.minDeposit
      ? `Minimal deposit Rp ${settings.minDeposit.toLocaleString('id-ID')}`
      : 'Maksimal deposit Rp 1.000.000';
  return res.status(400).json({ error: message });
}
    const invoice = await createInvoiceForUser(req.apiUser, amount, settings);
    return res.json({ success: true, invoice_id: invoice._id, amount: invoice.amount, fee: invoice.fee, total: invoice.total, qris_image: invoice.qris_image, expired_at: invoice.expiredAt });
  } catch (e) { console.error('API create invoice error:', e.message); if (botManager) botManager.notifyError('/api/invoice', e.message); return res.status(400).json({ error: e.message }); }
});
app.get('/api/invoice/status', apiAuth, async (req, res) => {
  const invoiceId = req.query.id || req.query.invoice_id;
  if (!invoiceId) return res.status(400).json({ error: 'Invoice ID diperlukan' });
  const invoice = await Invoice.findById(invoiceId);
  if (!invoice || invoice.userId.toString() !== req.apiUser.toString()) return res.status(404).json({ error: 'Invoice tidak ditemukan' });
  res.json({ invoice_id: invoice._id, amount: invoice.amount, fee: invoice.fee, total: invoice.total, status: invoice.status, qris_image: invoice.qris_image, expired_at: invoice.expiredAt, created_at: invoice.createdAt });
});

// ~~~~~~~~ GRACEFUL SHUTDOWN
process.once('SIGINT', async () => { if (botManager) await botManager.stopBot(); process.exit(0); });
process.once('SIGTERM', async () => { if (botManager) await botManager.stopBot(); process.exit(0); });

app.listen(PORT, () => console.log(`🚀 Server berjalan di http://localhost:${PORT}`));